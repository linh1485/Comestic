﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BLind.Controllers
{
    public class ChiTietSanPhamController : Controller
    {
        // GET: ChiTietSanPham
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Rafael()
        {
            return View();
        }
        public ActionResult Oscar()
        {
            return View();
        }
        public ActionResult ()
        {
            return View();
        }

    }
}